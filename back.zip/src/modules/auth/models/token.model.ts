export interface PayloadToken {
	role: string;
	sub: number;
}
